import React from 'react';
import fotoFinal from '../../../assets/Foto final.jpeg';

export default function Section5() {
    const numeroWhatsApp = "5491100000000";
    const mensaje = "¡Hola! Quiero confirmar mi asistencia a los XV de Luli. Mi nombre es: ";
    const linkWhatsApp = `https://wa.me/${numeroWhatsApp}?text=${encodeURIComponent(mensaje)}`;

    // Difuminamos solo la parte de ARRIBA de la foto del teatro. Abajo queda sólida.
    const fadeTopMask = {
        WebkitMaskImage: 'linear-gradient(to bottom, transparent 0%, black 25%, black 100%)',
        maskImage: 'linear-gradient(to bottom, transparent 0%, black 25%, black 100%)'
    };

    return (
        <section id="rsvp" className="relative flex flex-col items-center justify-center w-full pt-16">
            
            {/* Primero los textos de confirmación */}
            <div className="relative z-10 w-full max-w-sm mx-auto flex flex-col items-center text-center px-6 mb-4">
                <h2 className="text-5xl md:text-6xl text-[#8e514b] mb-4" style={{ fontFamily: "'Great Vibes', cursive" }}>
                    ¡Confirma tu <br/> asistencia!
                </h2>
                
                <p className="text-[#7a5048] text-lg font-serif mb-8 italic">
                    Para el XV de Luli, el viernes 8 de <br/> enero de 2027
                </p>

                <a 
                    href={linkWhatsApp}
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="group flex items-center justify-center gap-3 px-8 py-4 w-full rounded-full bg-[#dca8b2] text-white font-sans text-sm md:text-base tracking-wider shadow-lg hover:bg-[#c9959f] transition-colors"
                >
                    <svg viewBox="0 0 24 24" width="22" height="22" fill="currentColor">
                        <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51a12.8 12.8 0 0 0-.57-.01c-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 0 1-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 0 1-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 0 1 2.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0 0 12.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 0 0 5.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 0 0-3.48-8.413Z"/>
                    </svg>
                    <span>Confirmar por WhatsApp</span>
                </a>

                <p className="mt-6 text-sm text-[#8e514b]/80 font-sans italic">
                    Por favor, confirma antes del 15 de diciembre
                </p>
            </div>

            {/* Segundo, la foto del Teatro que cierra la página (-mt-12 para subir hacia el texto) */}
            <div className="w-full -mt-8">
                <img 
                    src={fotoFinal} 
                    alt="Luli Teatro" 
                    className="w-full h-[50vh] md:h-[60vh] object-cover block opacity-95"
                    style={fadeTopMask}
                />
            </div>
        </section>
    );
}