import React from 'react';
import foto1 from '../../../assets/Fotos1.jpeg';

export default function Section4() {
    // Difuminado muy suave (de 25% a 75% es sólido, el resto se mezcla)
    const fadeMaskStyle = {
        WebkitMaskImage: 'linear-gradient(to bottom, transparent 0%, black 25%, black 75%, transparent 100%)',
        maskImage: 'linear-gradient(to bottom, transparent 0%, black 25%, black 75%, transparent 100%)'
    };

    return (
        <section id="galeria" className="relative pt-4 pb-16 flex flex-col items-center w-full">
            <div className="relative w-full flex flex-col items-center text-center">

                <div className="w-full">
                    <img 
                        src={foto1} 
                        alt="Sesión Luli" 
                        className="w-full h-[60vh] md:h-[70vh] object-cover block opacity-95"
                        style={fadeMaskStyle}
                    />
                </div>

                <div className="relative z-10 w-full max-w-sm mx-auto px-6 flex flex-col items-center -mt-12">
                    {/* Ícono de Regalo */}
                    <div className="mb-4 text-[#8e514b] opacity-80">
                        <svg viewBox="0 0 24 24" width="36" height="36" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
                            <rect x="3" y="8" width="18" height="4" rx="1" />
                            <path d="M12 8v13" />
                            <path d="M19 12v7a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2v-7" />
                            <path d="M7.5 8a2.5 2.5 0 0 1 0-5A4.8 8 0 0 1 12 8a4.8 8 0 0 1 4.5-5 2.5 2.5 0 0 1 0 5" />
                        </svg>
                    </div>

                    <h3 className="text-3xl font-serif text-[#8e514b] mb-4">Regalos</h3>
                    <p className="text-[#7a5048] text-base font-serif italic mb-8 max-w-xs leading-relaxed">
                        Agradecemos profundamente su presencia como el mejor regalo. Para quienes deseen contribuir, una urna estará disponible en el salón, o mediante transferencia.
                    </p>

                    <div className="w-full border-t border-b border-[#8e514b]/20 py-5">
                        <div className="flex flex-col gap-3 text-[#8e514b] font-sans">
                            <div>
                                <span className="block text-xs uppercase tracking-widest mb-1 text-[#7a5048]">Alias</span>
                                <strong className="text-lg tracking-wide">LULI.XV.CBU</strong>
                            </div>
                            <div>
                                <span className="block text-xs uppercase tracking-widest mb-1 text-[#7a5048] mt-2">CBU</span>
                                <strong className="text-base tracking-wide break-all">1234567890123456789012</strong>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </section>
    );
}